# Projekt z programowania sieciowego

Uproszczoną wersja programu traceroute w postaci biblioteki.
Wykorzystuje protokół ICMP oraz UDP.
